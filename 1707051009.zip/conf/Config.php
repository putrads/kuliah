<?php
define("DB_HOST","localhost");
define("DB_USER","id11096277_root");
define("DB_PASSWORD","12345678");
define("DB_NAME","id11096277_putra_db");

// echo DB_HOST;
